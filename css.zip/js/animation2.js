ScrollReveal().reveal(".box", {
	easing: "ease-in-out",
	reset: !0,
	delay: "50",
	direction: "top",
	origin: "bottom",
	duration: 800,
	distance: "300px",
}),
	ScrollReveal().reveal(".icons", {
		reset: !0,
		delay: "50",
		direction: "right",
		origin: "bottom",
		duration: 800,
		distance: "100px",
	});
